import { Component, OnInit } from '@angular/core';
import { Menu } from 'src/app/Models/menu';
import { MenuService } from 'src/app/Service/menu.service';

@Component({
    selector: 'app-show-menu',
    templateUrl: './show-menu.component.html',
    styleUrls: ['./show-menu.component.css'],
})
export class ShowMenuComponent implements OnInit {
    menus: Menu[] = [];
    searchByName: string = '';
    constructor(private service: MenuService) {}
    ngOnInit(): void {
        this.service
            .getMenus()
            .subscribe((data: Menu[]) => (this.menus = data));
    }
    AddItem(id: number) {
        this.service.getMenu(id).subscribe((data: Menu) => {
            if (localStorage.getItem('cart')) {
                let items: Menu[] = JSON.parse(localStorage.getItem('cart')!);
                items.push(data);
                localStorage.setItem('cart', JSON.stringify(items));
            } else {
                localStorage.setItem('cart', JSON.stringify([data]));
            }
        });
    }
}
