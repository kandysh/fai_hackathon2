import { Component, OnInit } from '@angular/core';
import { Menu } from 'src/app/Models/menu';

@Component({
    selector: 'app-cart',
    templateUrl: './cart.component.html',
    styleUrls: ['./cart.component.css'],
})
export class CartComponent implements OnInit {
    cart: Menu[] = [];
    totalBill: number = 0;
    ngOnInit(): void {
        this.cart = JSON.parse(localStorage.getItem('cart')!);
        this.totalBill = this.cart.reduce(
            (accum, menu) => menu.price + accum,
            0
        );
    }
}
