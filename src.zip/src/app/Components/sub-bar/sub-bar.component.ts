import { Component } from '@angular/core';

@Component({
  selector: 'app-sub-bar',
  templateUrl: './sub-bar.component.html',
  styleUrls: ['./sub-bar.component.css']
})
export class SubBarComponent {

}
