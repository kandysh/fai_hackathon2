import { Pipe, PipeTransform } from '@angular/core';
import { Menu } from '../Models/menu';

@Pipe({
    name: 'search',
})
export class SearchPipe implements PipeTransform {
    transform(value: Menu[], args: string): Menu[] {
        if (args === '') return value;
        return value.filter((menu) => menu.name.toLowerCase().includes(args));
    }
}
