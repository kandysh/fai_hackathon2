import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Menu } from '../Models/menu';
@Injectable({
    providedIn: 'root',
})
export class MenuService {
    url = 'http:localhost:5232/menu';
    constructor(private http: HttpClient) {}
    getMenus() {
        return this.http.get<Menu[]>(this.url);
    }
    getMenu(id: number) {
        return this.http.get<Menu>(`${this.url}/${id}`);
    }
    AddMenu(menu: Menu) {
        return this.http.post<Menu>(this.url, menu);
    }
    DeleteMenu(id: number) {
        return this.http.delete<Menu>(`${this.url}/${id}`);
    }
    UpdateMenu(menu: Menu) {
        return this.http.put(`${this.url}/${menu.id}`, menu);
    }
}
