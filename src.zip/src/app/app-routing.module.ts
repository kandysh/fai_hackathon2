import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NavBarComponent } from './Components/nav-bar/nav-bar.component';
import { ShowMenuComponent } from './Components/show-menu/show-menu.component';
import { CartComponent } from './Components/cart/cart.component';

const routes: Routes = [
    { path: '', component: NavBarComponent },
    { path: 'menu', component: ShowMenuComponent },
    { path: 'cart', component: CartComponent },
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
})
export class AppRoutingModule {}
