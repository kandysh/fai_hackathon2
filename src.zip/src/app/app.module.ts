import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavBarComponent } from './Components/nav-bar/nav-bar.component';
import { ShowMenuComponent } from './Components/show-menu/show-menu.component';
import { CartComponent } from './Components/cart/cart.component';
import { SearchPipe } from './Pipes/search.pipe';
import { SubBarComponent } from './Components/sub-bar/sub-bar.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    ShowMenuComponent,
    CartComponent,
    SearchPipe,
    SubBarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
